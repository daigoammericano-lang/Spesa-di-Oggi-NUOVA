SPESA DI OGGI — PROGETTO ANDROID

Questa cartella contiene un progetto Android vero e proprio che usa una WebView locale sicura per ospitare l'index.html dell'app. Il login Google su Android passa dal sistema Android Credential Manager e poi consegna l'ID token al Firebase Web SDK dentro la pagina: non usa più il redirect Google dentro la WebView.

PRIMO PASSO OBBLIGATORIO — FIREBASE/GOOGLE
1. In Firebase Console > Project settings > General aggiungi una app Android con package:
   com.daigo.spesadioggi
2. Recupera la SHA-1 della chiave con cui firmerai l'APK e aggiungila all'app Android in Firebase.
3. In Authentication abilita Google come provider.
4. Recupera il Web Client ID OAuth della piattaforma Google (non l'Android Client ID).
5. Apri gradle.properties e sostituisci:
   SPESA_WEB_CLIENT_ID=CONFIGURA_WEB_CLIENT_ID
   con il vero valore, per esempio:
   SPESA_WEB_CLIENT_ID=1234567890-xxxxxxxxxxxxxxxx.apps.googleusercontent.com

BUILD
Apri la cartella in Android Studio e lascia che Gradle scarichi le dipendenze. Poi esegui Build > Build APK(s).

MICROFONO
Il progetto dichiara RECORD_AUDIO e concede alla pagina solo AUDIO_CAPTURE quando la richiesta proviene dall'origine locale dell'app.

FIREBASE WEB / FIRESTORE
Il file index.html mantiene la configurazione web Firebase e la logica Firestore già presente nella base. Il file docs/firestore.rules è quello da pubblicare nel progetto Firebase.

IMPORTANTE
Questo progetto non contiene un google-services.json fabbricato. Il file va generato dalla console Firebase per eventuali integrazioni native future; il bridge Google attuale usa invece il Web Client ID e il Firebase Web SDK già presente nell'index.html.

CONFIGURAZIONE FIREBASE INTEGRATA
Il progetto include app/google-services.json generato per il progetto Firebase spesa-di-oggi.
Il Web Client ID Google è già valorizzato in gradle.properties con l'ID presente nel file Firebase.
L'app utilizza il Web Client ID per il Credential Manager Android e consegna l'ID token al Firebase Web SDK.
