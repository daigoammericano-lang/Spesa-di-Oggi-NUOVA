# Spesa di Oggi: no custom shrinking rules required for debug/release test builds.
