import groovy.json.JsonSlurper

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

fun firebaseWebClientId(): String {
    val file = file("google-services.json")
    if (!file.exists()) return "CONFIGURA_WEB_CLIENT_ID"
    return try {
        val root = JsonSlurper().parse(file) as Map<*, *>
        val clients = root["client"] as? List<*> ?: emptyList<Any>()
        for (client in clients) {
            val obj = client as? Map<*, *> ?: continue
            val oauth = obj["oauth_client"] as? List<*> ?: continue
            for (entry in oauth) {
                val item = entry as? Map<*, *> ?: continue
                if ((item["client_type"] as? Number)?.toInt() == 3) {
                    val id = item["client_id"] as? String
                    if (!id.isNullOrBlank()) return id
                }
            }
        }
        "CONFIGURA_WEB_CLIENT_ID"
    } catch (_: Exception) {
        "CONFIGURA_WEB_CLIENT_ID"
    }
}

android {
    namespace = "com.daigo.spesadioggi"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.daigo.spesadioggi"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        resValue("string", "default_web_client_id", firebaseWebClientId())
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")

    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
}
