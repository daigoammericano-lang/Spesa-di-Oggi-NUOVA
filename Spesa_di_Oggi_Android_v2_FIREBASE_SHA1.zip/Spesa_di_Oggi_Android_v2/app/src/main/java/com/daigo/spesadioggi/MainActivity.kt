package com.daigo.spesadioggi

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.security.SecureRandom
import android.util.Base64

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var credentialManager: CredentialManager
    private val notificationChannelId = "spesa_di_oggi"

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        credentialManager = CredentialManager.create(this)
        createNotificationChannel()

        webView = WebView(this)
        setContentView(webView)

        configureWebView()
        webView.addJavascriptInterface(AndroidBridge(this), "AndroidAPI")
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun configureWebView() {
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            builtInZoomControls = false
            displayZoomControls = false
        }

        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ) = assetLoader.shouldInterceptRequest(request.url)
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val audioOnly = request.resources.all { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                    val trustedOrigin = request.origin?.host == "appassets.androidplatform.net"
                    if (audioOnly && trustedOrigin &&
                        ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    ) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    } else {
                        request.deny()
                        if (audioOnly && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                            requestMicrophonePermission()
                        }
                    }
                }
            }
        }
    }

    private fun requestMicrophonePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 4101)
        }
    }

    private fun startNativeGoogleLogin() {
        val clientId = getString(R.string.default_web_client_id).trim()
        if (clientId.isBlank() || clientId == "CONFIGURA_WEB_CLIENT_ID") {
            sendJsError("Manca il Web Client ID Google: configura SPESA_WEB_CLIENT_ID in gradle.properties.")
            return
        }

        lifecycleScope.launch {
            try {
                val option = GetSignInWithGoogleOption.Builder(clientId)
                    .setNonce(generateSecureRandomNonce())
                    .build()
                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(option)
                    .build()
                val result = credentialManager.getCredential(
                    context = this@MainActivity,
                    request = request
                )
                handleGoogleCredential(result)
            } catch (e: GetCredentialException) {
                sendJsError("Accesso Google non completato: ${e.message ?: "operazione annullata"}")
            } catch (e: Exception) {
                sendJsError("Accesso Google non completato: ${e.message ?: "errore inatteso"}")
            }
        }
    }

    private fun handleGoogleCredential(result: GetCredentialResponse) {
        val credential = result.credential
        if (credential !is CustomCredential ||
            credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            sendJsError("Google non ha restituito una credenziale di accesso valida.")
            return
        }

        try {
            val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data)
            val token = googleIdToken.idToken
            if (token.isBlank()) {
                sendJsError("Token Google vuoto.")
                return
            }
            val safeToken = JSONObject.quote(token)
            runOnUiThread {
                webView.evaluateJavascript(
                    "window.completeNativeGoogleLogin && window.completeNativeGoogleLogin($safeToken);",
                    null
                )
            }
        } catch (e: GoogleIdTokenParsingException) {
            sendJsError("Risposta Google non valida: ${e.message ?: "token non leggibile"}")
        }
    }

    private fun sendJsError(message: String) {
        val safe = JSONObject.quote(message)
        runOnUiThread {
            webView.evaluateJavascript(
                "window.nativeGoogleLoginError && window.nativeGoogleLoginError($safe);",
                null
            )
        }
    }

    private fun generateSecureRandomNonce(byteLength: Int = 32): String {
        val bytes = ByteArray(byteLength)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(
            bytes,
            Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING
        )
    }

    private fun clearCredentialState() {
        lifecycleScope.launch {
            runCatching {
                credentialManager.clearCredentialState(androidx.credentials.ClearCredentialStateRequest())
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                notificationChannelId,
                "Spesa di Oggi",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifiche della lista condivisa"
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showNotification(title: String, message: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val notification = NotificationCompat.Builder(this, notificationChannelId)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(title.take(80))
            .setContentText(message.take(200))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    private fun vibrate() {
        if (Build.VERSION.SDK_INT >= 31) {
            val vibrator = getSystemService(VibratorManager::class.java).defaultVibrator
            vibrator.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(120)
        }
    }

    inner class AndroidBridge(private val context: Context) {
        @JavascriptInterface
        fun startNativeGoogleLogin() {
            runOnUiThread { startNativeGoogleLogin() }
        }

        @JavascriptInterface
        fun requestMicrophonePermission() {
            runOnUiThread { this@MainActivity.requestMicrophonePermission() }
        }

        @JavascriptInterface
        fun requestNotificationPermission(appName: String?) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                runOnUiThread {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }

        @JavascriptInterface
        fun showNotification(title: String?, message: String?) {
            runOnUiThread { this@MainActivity.showNotification(title ?: "Spesa di Oggi", message ?: "") }
        }

        @JavascriptInterface
        fun vibrate() {
            runOnUiThread { this@MainActivity.vibrate() }
        }

        @JavascriptInterface
        fun clearCredentialState() {
            runOnUiThread { this@MainActivity.clearCredentialState() }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
