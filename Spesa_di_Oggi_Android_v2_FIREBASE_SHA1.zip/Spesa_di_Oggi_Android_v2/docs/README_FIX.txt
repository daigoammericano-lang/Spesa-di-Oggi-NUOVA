SPESA DI OGGI — FIX COMPLETA DEL CODICE

- Google: rileva Android WebView e usa signInWithRedirect/getRedirectResult; browser normale mantiene popup.
- Audio add: suono incorporato nell'HTML, nessuna dipendenza da sounds/Aggiungi.mp3.
- Sblocco audio: primo gesto utente prepara la riproduzione; PARLA usa lo sblocco prima del riconoscimento vocale.
- Condivisione: Firestore registra lastAction; gli altri dispositivi emettono il suono solo per add remoti.
- Acquisto, quantità, prezzo, edit e rimozione non emettono il suono di add.
- Su AndroidAPI, gli add remoti possono anche generare notifica nativa e vibrazione.
- Regole Firestore aggiornate per consentire e validare lastAction.
- Script JS verificati con Node --check.

Per rendere effettive le modifiche, va pubblicato index.html sul Firebase Hosting e vanno pubblicate le firestore.rules; l'APK attuale in modalità URL deve poi puntare alla pagina pubblicata. La ricompilazione richiede l'ambiente HTML-to-APK/Android che possiede il progetto.
