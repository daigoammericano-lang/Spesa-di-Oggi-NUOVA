SPESA DI OGGI — PROGETTO ANDROID v2

Base: versione FIX COMPLETA dell'app, caricata nella WebView locale sicura.
Package Android: com.daigo.spesadioggi
Firebase project: spesa-di-oggi

CONFIGURAZIONE FIREBASE
- Il file app/google-services.json è già presente ed è quello reale scaricato dal progetto Firebase.
- Il build script legge automaticamente dal JSON il Web Client ID OAuth Google (client_type 3) e lo espone alla MainActivity come default_web_client_id.
- Prima del primo build, aggiungere alla registrazione Android in Firebase la SHA-1 e la SHA-256 del certificato con cui verrà firmata l'APK.
- In Firebase Authentication, mantenere Google abilitato.

ARCHITETTURA
- Android nativo (Kotlin/Gradle).
- UI dell'app: index.html locale in WebView.
- Google Sign-In: Credential Manager nativo -> ID token -> Firebase Web SDK tramite completeNativeGoogleLogin().
- Microfono: permesso RECORD_AUDIO nativo + concessione WebView solo per AUDIO_CAPTURE dell'origine locale dell'app.
- Firestore e resto della logica lista restano nell'index.html.

BUILD
Aprire la cartella in Android Studio e sincronizzare Gradle. Poi Build > Build APK(s).

NOTA
Il file google-services.json è incluso per questa app Android reale. Non va caricato pubblicamente in repository aperti insieme a una chiave di firma privata. Le chiavi Firebase client-side non sono segreti, ma il keystore di firma sì.
